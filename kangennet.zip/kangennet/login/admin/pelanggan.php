
<?php
//mengaktifkan session
@session_start();

require_once ('koneksi.php');

$query = mysqli_query($connection,"select * from pelanggan order by id_p ASC");

?>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
</head>

<!-- Atas nya-->
          <ol class="breadcrumb" style="margin-left: -6px; margin-bottom:15px; padding-bottom:15px; padding-top:15px;">
            <li class="breadcrumb-item">
              <a href="index.php">Beranda</a>
            </li>
            <li class="breadcrumb-item active">Pelanggan</li>
          </ol>

		<!-- End -->
		
<div class="container" style="margin-left: -20px">
	<div class="row">
	
<div class="col-md-9">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><i class="fa fa-users"></i> Data Pelanggan</h3>
				  </div>
				    
			  <div class="panel-body">
			   <a href="index.php?page=tambahdata" style=".height: 0;overflow: hidden;position: absolute;"><button type="submit" class="btn btn-primary">Tambah Data</button></a>
			 <a href="printpdf.php" style="margin-left:725px;"><i class="fa fa-print"> Cetak PDF</i></a>
			   <div style="margin-bottom:45px;"></div> 
			     
	<table class="table table-bordered" id="dataTable">
		<thead>
          <tr>
		   <th style="color:black;">Nama</th>
           <th style="color:black">Alamat</th>
           <th style="color:black">Tanggal Bayar</th>
           <th style="color:black">Jumlah</th>
           <th style="color:black">Paket</th>
           <th style="color:black" colspan="2">Aksi</th>
         </tr> 
		</thead>
			   
		   <?php if(mysqli_num_rows($query)>0){ ?>
		   <?php 
		   $no = 1;
		   while($data = mysqli_fetch_array($query)){
			   ?>
		
		<tbody>		
           <tr>
                <td><?php echo $data["nama"]; ?></td>
				<td><?php echo $data["alamat"]; ?></td>
                <td><?php echo $data["tanggal"]; ?></td>
                <td><?php echo $data["jumlah"]; ?></td>
                <td><?php echo $data["paket"]; ?></td>
                <td><a href="hapusp.php?id_p=<?php echo $data['id_p'] ?>"><center><button type="submit" class="btn btn-primary" style="margin-top:-2px; margin-bottom:-2px;"> Hapus</button></center></a></td>
				<td><a href="index.php?page=editdata&?id_p=<?php echo $data['id_p'] ?>"><center><button type="submit" class="btn btn-primary" style="margin-top:-2px; margin-bottom:-2px;"> Edit</button></center></a></td>
				
            </tr>
		</tbody>
           <?php $no++; } ?>
			<?php } ?>

     </table>	
	</div>	
</div>
</div>