<?php
//mengaktifkan session
@session_start();

require_once ('koneksi.php');

$query = mysqli_query($connection,"select * from ks");

?>
<!-- Atas nya-->
          <ol class="breadcrumb" style="margin-left: -6px; margin-bottom:15px; padding-bottom:15px; padding-top:15px;">
            <li class="breadcrumb-item">
              <a href="index.php">Beranda</a>
            </li>
            <li class="breadcrumb-item active">Komentar</li>
          </ol>

		<!-- End -->
		
<div class="container" style="margin-left: -20px">
	<div class="row">
	
<div class="col-md-9">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><i class="fa fa-comments-o"></i> Komentar</h3>
				  </div>
			  <div class="panel-body">
			  
			  
			  
<table class="table table-bordered" id="dataTable">
		<thead>
          <tr>
		   <th style="color:black;">Nama</th>
           <th style="color:black">Email</th>
           <th style="color:black">Judul</th>
           <th style="color:black">Pesan</th>
           <th style="color:black">Aksi</th>
         </tr> 
		</thead>
			   
		   <?php if(mysqli_num_rows($query)>0){ ?>
		   <?php 
		   $no = 1;
		   while($data = mysqli_fetch_array($query)){
			   ?>
		
		<tbody>		
           <tr>
        
                <td><?php echo $data["nama"]; ?></td>
               <td><?php echo $data["email"]; ?></td>
               <td><?php echo $data["judul"]; ?></td>
                <td><?php echo $data["pesan"]; ?></td>
                <td><a href="hapusks.php?id_ks=<?php print $data['id_ks'] ?>"> Hapus</button></a></td>
				 
            </tr>
		</tbody>
           <?php $no++; } ?>
			<?php } ?>

     </table>
	
	</div>
</div>
</div>