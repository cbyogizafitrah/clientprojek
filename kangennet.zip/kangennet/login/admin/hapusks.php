
<?php
include "koneksi.php";

$id_ks = $_GET ['id_ks'];

if(!empty($id_ks)) {
	
$query = mysqli_query($connection,"delete from ks where id_ks = '$id_ks'");

	header('location:index.php?page=komentar');
	
}
else{
	
}
?>