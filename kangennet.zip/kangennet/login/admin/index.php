<?php
session_start();

if(!isset($_SESSION['logged_in']))
{
 header("Location: index.php");
}

require_once ('koneksi.php');

$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Kangen-Net</title>
	<link rel="shortcut icon" type="image/icon" href="favicon1.ico"/>
    <!--  -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.js"></script>
<style>
.navbar-inverse {
  background-color: #343a40;
  border-color: #343a40;
 } 
 </style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
     <table>
       <tr>
         <td>
            <img src="logo1.png" class="img-responsive" width="80" height="80">
         </td>
         <td>
           <a style="color:white;" class="navbar-brand" href="#">  &nbsp;| Hai.  <b> <?php echo $row['nama'] ?> </b> </a>
         </td>
       </tr>
     </table>
    </div>
        <div id="navbar" class="navbar-collapse collapse">
        	<div class="navbar-form navbar-right">
			<div class="navbar-left" style="color:white; padding-right:20px; padding-top:7px;">
			<!-- Baut tanggal dan jam -->
			<?php 
			$tanggal = mktime(date("m"),date("d"),date("Y"));
			echo "Tanggal : <b>".date("d-M-Y", $tanggal)."</b>";
			date_default_timezone_set('Asia/Jakarta');
			$jam=date("H:i:s");
			echo " | Pukul : <b>". $jam." ". "</b>";
			$a = date ("H");
			if (($a>=6) && ($a<=11)){
			echo "<b>, Selamat Pagi !! </b>";
			}
			else if(($a>11) && ($a<=15))
			{
			echo ", Selamat Pagi !!";}
			else if (($a>15) && ($a<=18)){
			echo ", Selamat Siang !!";}
			else { echo ", <b> Selamat Malam </b>";}
			?>
<!-- Baut tanggal dan jam --> 
</div>
				<a href="logout.php" type="submit" class="btn btn-success"><i class="fa fa-sign-out"></i> Logout</a>
        	</div>
      </div>
    </nav>
<div class="container" style="margin-top: 80px">
	<div class="row">
		<div class="col-md-3">
			<div class="list-group">
			  <a class="list-group-item active" style="text-align: center;background-color: #343a40;border-color: #343a40">
			    ADMINISTRATOR
				
              </a>
              <a href="index.php?page=beranda" class="list-group-item" ><i class="fa fa-home"></i> Beranda</a>
              <a href="index.php?page=pelanggan" class="list-group-item" ><i class="fa fa-users"></i> Pelanggan</a>
			  <a href="index.php?page=tambahdata" class="list-group-item" style=".height: 0;overflow: hidden;position: absolute;"><i class="fa fa-users"></i> Tambah Data</a> 
			  <a href="index.php?page=editdata" class="list-group-item" style=".height: 0;overflow: hidden;position: absolute;"><i class="fa fa-users"></i> Edit Data</a> 
              <a href="index.php?page=diagram" class="list-group-item" ><i class="fa fa-bar-chart"></i> Diagram</a>
              <a href="index.php?page=komentar" class="list-group-item" ><i class="fa fa-comments-o"></i> Komentar</a>
              
            </div>
		</div>
		<div class="col-md-9">
			
			

<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			case 'beranda':
				require_once "beranda.php";
				break;
			case 'pelanggan':
				require_once "pelanggan.php";
				break;
			case 'diagram':
				require_once "diagram.php";
				break;		
			case 'komentar':
				require_once "komentar.php";
				break;
			case 'tambahdata':
				require_once "tambahdata.php";
				break;		
			case 'editdata';
				require_once "updatep.php";
				break;					
			default:
				echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
				break;
		}
	}else{
		include "beranda.php";
	}
 
	 ?>
			
		</div>
	</div>
</div>
</body>
</html>

