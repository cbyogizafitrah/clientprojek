<?php

require_once ('koneksi.php');

$session = $_SESSION['logged_in'];

$query  = "SELECT * FROM users WHERE id_user = '$session'";
$result = mysqli_query($connection,$query)or die(mysqli_error());
$row     = mysqli_fetch_array($result);

?>

<!-- Atas nya-->
          <ol class="breadcrumb" style="margin-left: -6px; margin-bottom:15px; padding-bottom:15px; padding-top:15px;">
            <li class="breadcrumb-item">
              <a href="index.php">Beranda</a>
            </li>
            <li class="breadcrumb-item active">Komentar</li>
          </ol>

		<!-- End -->
		
<div class="container" style="margin-left: -20px">
	<div class="row">
	
<div class="col-md-9">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><i class="fa fa-comments-o"></i> Komentar</h3>
				  </div>
			  <div class="panel-body">
			  
			  
			  
   <!-- Area Chart Example-->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-chart-area"></i>
             Data Pelanggang Per-tahun berdasarkan Diagram Coloumn </div>
            <div class="card-body">
              <canvas id="myAreaChart" width="100%" height="30"></canvas>
			  <?php
					//koneksi ke database
					$conn = new mysqli("localhost", "root", "", "kangennet");
					if ($conn->connect_errno) {
						echo die("Failed to connect to MySQL: " . $conn->connect_error);
					}
					 
					$rows = array();
					$table = array();
					$table['cols'] = array(
						//membuat label untuk nama nya, tipe string
						array('label' => 'Tahun', 'type' => 'string'),
						//membuat label untuk jumlah siswa, tipe harus number untuk kalkulasi persentasenya
						array('label' => 'Pelanggan', 'type' => 'number')
					);
					 
					//melakukan query ke database select
					$sql = $conn->query("SELECT * FROM rekap");
					//perulangan untuk menampilkan data dari database
					while($data = $sql->fetch_assoc()){
						//membuat array
						$temp = array();
						//memasukkan data pertama yaitu nama kelasnya
						$temp[] = array('v' => (string)$data['tahun']);
						//memasukkan data kedua yaitu jumlah siswanya
						$temp[] = array('v' => (int)$data['jumlah_pelanggan']);
						//memasukkan data diatas ke dalam array $rows
						$rows[] = array('c' => $temp);
					}
					 
					//memasukkan array $rows dalam variabel $table
					$table['rows'] = $rows;
					//mengeluarkan data dengan json_encode. silahkan di echo kalau ingin menampilkan data nya
					$jsonTable = json_encode($table);
					 
					?>
					<html>
					 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
					   <script type="text/javascript">
					   	google.charts.load('current', {packages:['corechart']});
						google.charts.setOnLoadCallback(drawChart);
					 
						function drawChart() {
					 
							// membuat data chart dari json yang sudah ada di atas
							var data = new google.visualization.DataTable(<?php echo $jsonTable; ?>);
					 
							// Set options, bisa anda rubah
							var options = {'title':'Data Pelanggan',
										   'width':500,
										   'height':400};
					 
							var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
							chart.draw(data, options);
						}
						</script>
						<div id="chart_div"></div>
						</html>
            </div>
            <div class="card-footer small text-muted">Data diperbarui 11 Januari 2018</div>
          </div>
	<!-- -->
	
	</div>
</div>
</div>