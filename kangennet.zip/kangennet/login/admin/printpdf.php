<?php
// memanggil library FPDF
require('fpdf.php');
// intance object dan memberikan pengaturan halaman PDF
$pdf = new FPDF('l','mm','A4');
// membuat halaman baru
$pdf->AddPage();
$pdf->Image('logo1.png',115,10, 70,20);
$pdf->Cell(10,7,'',0,1);
// setting jenis font yang akan digunakan
$pdf->SetFont('Arial','B',11);
$pdf->Cell(10,7,'',0,1);
$pdf->Cell(10,7,'',0,1);
$pdf->Cell(0,7,'Jalan Lintas Bagansiapiapi, Mukti Jaya - Rokan Hilir',0,1,'C');
// mencetak string 
//$pdf->Cell(70,0.4,"Tanggal : ".date("D-d/m/Y"),1,0,'A');
//$pdf->Cell(190,7,'KANGEN-NET',0,1,'C');
$pdf->SetFont('Arial','B',12);

$pdf->Cell(10,7,'',0,1);
$pdf->Cell(5);
$pdf->Cell(0,7,'DAFTAR PELANGGAN',0,1,'C');

//space
//$pdf->Cell(10,7,'',0,1);
$pdf->Cell(40);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(60,6,'Nama',1,0);
$pdf->Cell(50,6,'Alamat',1,0);
$pdf->Cell(30,6,'Tanggal Bayar',1,0);
$pdf->Cell(25,6,'Jumlah',1,0);
$pdf->Cell(20,6,'Paket',1,1);

$pdf->SetFont('Arial','',10);

include 'koneksi.php';
$query = mysqli_query($connection, "select * from pelanggan");
while($row = mysqli_fetch_array($query)){
		$pdf->Cell(40);
		$pdf->Cell(60,6,$row['nama'],1,0);
		$pdf->Cell(50,6,$row['alamat'],1,0);
		$pdf->Cell(30,6,$row['tanggal'],1,0);
		$pdf->Cell(25,6,$row['jumlah'],1,0);
		$pdf->Cell(20,6,$row['paket'],1,1);
}
$pdf->Output("Data Pelanggan.pdf","I");

?>
		