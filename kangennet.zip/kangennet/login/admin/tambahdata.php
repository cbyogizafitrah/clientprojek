<?php
//mengaktifkan session
include ('koneksi.php');
$query = mysqli_query($connection,"select * from pelanggan order by id_p ASC");

?>

<!-- 1 -->

<!-- Atas nya-->
            <ol class="breadcrumb" style="margin-left: -6px; margin-bottom:15px; padding-bottom:15px; padding-top:15px;">
            <li class="breadcrumb-item">
              <a href="index.php">Beranda</a>
            </li>
			<li class="breadcrumb-item">
			<a href="index.php?page=pelanggan">Pelanggan</a>
			  </li>
            <li class="breadcrumb-item active">Tambah Data</li>
          </ol>

		<!-- End -->
		
<div class="container" style="margin-left: -20px">
	<div class="row">
	
<div class="col-md-9">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><i class="fa fa-users"></i> Data Pelanggan</h3>
				  </div>
				    
			  <div class="panel-body">
			  

				<form action="inputdb.php" method="POST">
				   
					<table id="table1">

						<tr>

							<td style="padding:5px"><b>Nama </b></td>
							<td style="padding:5px"><input type="text" name="nama" class="form-control"  required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
						</tr>
						<tr>
							<td style="padding:5px"><b>Alamat</b></td>
							<td style="padding:5px"><input type="text" name="alamat" class="form-control"  required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
						</tr>
						<tr>
							<td style="padding:5px"><b>Tanggal Bayar</b></td>
							<td style="padding:5px"><input type="date" name="tanggal" class="form-control"required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
							
						<tr>
							<td style="padding:5px"><b>Jumlah Tagihan</b></td>
							<td style="padding:5px"><input type="text" name="jumlah" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
						</tr>
						<tr>	
							<td style="padding:5px"><b>Paket</b></td>
							<td style="padding:5px">
							<select name="paket" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">  
								<option value="">Silahkan Pilih</option>  
								<option value="1 Mbps">1 Mbps</option>  
								<option value="2 Mbps">2 Mbps</option>  
								<option value="3 Mbps">3 Mbps</option>  
								<option value="4 Mbps">4 Mbps</option>  
								<option value="5 Mbps">5 Mbps</option>  
								<option value="6 Mbps">6 Mbps</option>  
								<option value="7 Mbps">7 Mbps</option>  
								<option value="8 Mbps">8 Mbps</option>  
								<option value="9 Mbps">9 Mbps</option>  
								<option value="10 Mbps">10 Mbps</option>  
								<option value="20 Mbps">20 Mbps</option>  
							</select> 
							
							</td>			
						
						</tr>
							<td style="padding:5px"></td>
							<td style="padding:5px">   <button type="submit" class="btn btn-primary" name="submitted" value="simpan">Simpan</button>
                            <button type="reset" class="btn btn-danger">Batal</button></td>
						</tr>
					</table>
				</form>
				
			  </div>
			</div>
		</div>
		</div>
</div>
		<!-- 1 -->
</html>