<?php
include "koneksi.php";

$id_p = $_GET ['id_p'];

if(!empty($id_p)) {
	
$query = mysqli_query($connection,"delete from pelanggan where id_p = '$id_p'");

	header('location:index.php?page=pelanggan');
	
}
else{
	
}
?>