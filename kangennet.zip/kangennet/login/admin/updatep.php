<?php
//mengaktifkan session
include 'koneksi.php';

?>
<!-- 1 -->
<!-- Atas nya-->
            <ol class="breadcrumb" style="margin-left: -6px; margin-bottom:15px; padding-bottom:15px; padding-top:15px;">
            <li class="breadcrumb-item">
              <a href="index.php">Beranda</a>
            </li>
			<li class="breadcrumb-item">
			<a href="index.php?page=pelanggan">Pelanggan</a>
			  </li>
            <li class="breadcrumb-item active">Update Data</li>
          </ol>

		<!-- End -->
		
<div class="container" style="margin-left: -20px">
	<div class="row">
	
<div class="col-md-9">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><i class="fa fa-users"></i> Data Pelanggan</h3>
				  </div>
				    
			  <div class="panel-body">
			  <?php include "koneksi.php";
			  $id_p = $_GET['id_p'];
			  $query = mysqli_query($connection,"select * from pelanggan where id_p='$id_p'")or die(mysql_error());
			  $nomor = 1;
			 while($data=mysqli_fetch_array($query)){
			  ?>

				<form action="updatedb.php" method="POST">
				   
					<table id="table1">

						<tr>

							<td style="padding:5px"><b>Nama </b></td>
							<td style="padding:5px">
							<input type="hidden" name="id_p" value="<?php echo $data['id_p']; ?>">
							<input type="text" name="nama" value="<?php echo $data['nama']; ?>" class="form-control"  required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
						</tr>
						<tr>
							<td style="padding:5px"><b>Alamat</b></td>
							<td style="padding:5px"><input type="text" name="alamat" value="<?php echo $data['alamat']; ?>" class="form-control"  required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
						</tr>
						<tr>
							<td style="padding:5px"><b>Tanggal Bayar</b></td>
							<td style="padding:5px"><input type="date" name="tanggal" value="<?php echo $data['tanggal']; ?>"class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
							
						<tr>
							<td style="padding:5px"><b>Jumlah Tagihan</b></td>
							<td style="padding:5px"><input type="text" name="jumlah" value="<?php echo $data['jumlah']; ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
						</tr>
						<tr>	
							<td style="padding:5px"><b>Paket</b></td>
							<td style="padding:5px"><input type="text" name="paket" value="<?php echo $data['paket']; ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')"></td>
								
								 
							</select> 
							
							</td>			
						
						</tr>
							<td style="padding:5px"></td>
							<td style="padding:5px">   <button type="submit" class="btn btn-primary" name="submitted" value="simpan">Simpan</button>
                            <button type="reset" class="btn btn-danger">Batal</button></td>
						</tr>
					</table>
				</form>
			 <?php } ?>
			  </div>
			</div>
		</div>
		</div>
</div>
		<!-- 1 -->
	
</html>