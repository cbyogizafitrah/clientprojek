
<?php 
include 'koneksi.php';

$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$tanggal = $_POST['tanggal'];
$jumlah = $_POST['jumlah'];
$paket = $_POST['paket'];

$query  = mysqli_query($connection,"INSERT INTO pelanggan VALUES('','$nama','$alamat','$tanggal','$jumlah','$paket')");
header("location:index.php?page=pelanggan");
?>