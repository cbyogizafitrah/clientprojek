<?php
include 'koneksi.php';

//data
$id_p = $_POST['id_p'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$tanggal = $_POST['tanggal'];
$jumlah = $_POST['jumlah'];
$paket = $_POST['paket'];

//update
mysqli_query($connection,"update pelanggan set nama='$nama',alamat='$alamat',tanggal='$tanggal',jumlah='$jumlah',paket='$paket' where id_p='$id_p'");

//peralihan
header("location:index.php?page=pelanggan");

?>