
<?php 
include 'koneksi.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$judul= $_POST['judul'];
$pesan = $_POST['pesan'];

$query  = mysqli_query($connection,"INSERT INTO ks VALUES('','$nama','$email','$judul','$pesan')");
header("location:bantuan.php");
?>