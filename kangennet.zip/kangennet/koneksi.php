<?php


//membuat deklarasi variable
$hostname = "localhost";
$username = "root";
$password = "";
$database = "kangennet";
//create variable connectin
$connection = mysqli_connect($hostname, $username, $password, $database);
// Check connection
if (mysqli_connect_errno()) {
  echo "Tidak terkoneksi ke database: " . mysqli_connect_error();
}

?>