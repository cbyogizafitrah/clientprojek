-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 02 Agu 2018 pada 23.23
-- Versi Server: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kangennet`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `ks`
--

CREATE TABLE `ks` (
  `id_ks` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `pesan` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_p` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL,
  `paket` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_p`, `nama`, `alamat`, `tanggal`, `jumlah`, `paket`) VALUES
(19, 'Warnet Hasibuan', 'Simpang Benar', '2017-01-15', '800.000', '4 Mbps'),
(20, 'M. Ponsel', 'Simpang Benar', '2017-02-05', '400.0000', '2 Mbps'),
(21, 'Graha Yamaha', 'Simpang Benar', '2017-03-05', '250.000', '1 Mbps'),
(22, 'Cafe Pelangi', 'Simpang Benar', '2017-03-05', '500.000', '5 Mbps'),
(23, 'Idola Ban', 'Simpang Benar', '2017-04-05', '300.000', '3 Mbps'),
(24, 'Bengkel Papandayan', 'Ujung Tanjung', '2018-01-01', '300.000', '2 Mbps'),
(25, 'Bengkel Las Rahuk Gundul', 'C Rahuk Sp Benar', '2018-02-05', '500.000', '3 Mbps'),
(26, 'Bengkel Tanah Putih', 'Tanah Putih TJ', '2018-02-20', '1.000.000', '8 Mbps'),
(27, 'Cafe Pelangi', 'SP Benar', '2018-03-10', '500.000', '5 Mbps'),
(28, 'Dongan Motor', 'Ujung Tanjung', '2018-04-10', '500.000', '3 Mbps'),
(29, 'Dr Meliana', 'SP Benar', '2018-04-20', '350.000', '2 Mbps');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekap`
--

CREATE TABLE `rekap` (
  `tahun` int(11) NOT NULL,
  `jumlah_pelanggan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rekap`
--

INSERT INTO `rekap` (`tahun`, `jumlah_pelanggan`) VALUES
(2017, 5),
(2018, 6),
(2019, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `email`, `password`, `nama`) VALUES
(2, 'info@kangen-net.com', 'kangensekali', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ks`
--
ALTER TABLE `ks`
  ADD PRIMARY KEY (`id_ks`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_p`);

--
-- Indexes for table `rekap`
--
ALTER TABLE `rekap`
  ADD PRIMARY KEY (`tahun`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ks`
--
ALTER TABLE `ks`
  MODIFY `id_ks` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_p` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
